package juego;

public enum Casillero {

	VACIO,
	ROJO,
	AMARILLO
}
